# D238 fresh six-store recorder result observation

This source/host preparation is fixed to attempt
771c04943d4c4a759055d794fa4b706e, session8582740024591403637,
historical compile HEAD1b2af246cd88e6207e846ee340f8c4e46a5bb980 and source
289300a4be9547cd294dc1f753bbe17a429d16776c46467fec5417b1290f4ffc.
The static/default recorder.ino package is 55376 bytes, SHA256
3b4812a7a57ec964437d6d1048f96724e3fed5d0a3f9419acd26adbcd5e70a5d,
MATCH0/MOTORS_ALLOWED0. No firmware, deadline, owner policy or grant changes.

Execute only from the separate sumox-recorder-six-result-20260927 worktree.
Its reviewed collector HEAD is distinct from the frozen historical compile
HEAD. The four closed compile records are byte-exact copies from the native
worktree's recorder-771c04943d4c4a75 owner. All145 input files must match their
historical Git blobs and current bytes; recompute all110 staged files including
the identified header. Fresh collector source/plan/records bind to its own
clean reviewed HEAD. No equality between those HEADs is required.

`derive01.py` pins the three accepted D233 templates and records every literal
substitution. Each generated tool reverses completely to its original bytes.
Changes are only module/path/attempt/head/session/source/package identities,
scope label and the capture helper's consequent exact size/hash. Preserve the
accepted D233 contracts and tools. Their execution paths and strict guards are
unchanged; no generic adapter, extra transport or new diagnostic field is added.

File-only ABI queries retain four bounded children: installed readelf/gdb
versions, readelf headers/sections/symbols and offline GDB over this exact ELF.
Retain -nx/-nh/-batch, disabled auto-load/function calls, no target/attach or
memory examination. Fresh observations cover9 types,11 windows,64 fields and
9 enum types, including the eight-byte D231 FailureRecord. All533 expression
lines remain unchanged. Validate exact initialized section intervals, object
size/alignment/nonoverlap, window/field bounds, enum values and bool width.
The runner must match bss_zero; native_dump may match the exact data_copy or
bss_zero interval appropriate to its actual ELF section. No old addresses,
object sizes or status values fill missing answers.

Retain all inherited source/descriptor/process/boot/identity guards and twelve
independent closing file checks. Child60s/reap5s,1MiB streams,400s transport,
8MiB reply,30000 UTF16 command units and128MiB local-free floor are unchanged.
The local native_abi01 owner is absent-only and consumed even on partial work;
remote recorder-771c04943d4c4a75-failure-abi01 must remain absent. No retry,
reset, upload, UART operation, register write or cleanup is authorized here.

Under root D051 scheduling authorization, reviewed offline file-only queries
over the closed compiled files may overlap the bounded receiver. This step
has no MCU/UART/OpenOCD/build/upload/cleanup effect. Passive MCU capture always
waits until delivery and receiver close. Root may omit capture after fully
validated delivery if it adds no useful evidence; preparation is not a claim
that execution is necessary or already accepted.

After review and exact commit, root sets H to this worktree's clean HEAD:

    python -B tools/recorder_six_result_abi.py --check-only --reviewed-head H
    python -B tools/recorder_six_result_abi.py --execute --reviewed-head H

The ABI owner is state/analysis/P7_recorder_six_result_raw/native_abi01. Preserve
every result and closing error. Root accepts the fresh ABI before using its
exact abi.json hash to prepare the three mechanical capture bindings described
in P7_recorder_six_result_caller_contract.md. Actual ABI evidence and binding
files are committed before capture check/execute at its new clean collector
HEAD. These data-only bindings require no second source-review chain; material
source changes do. An unsuccessful owner is never reused.

Passive capture retains complete263680B loader and55376B sketch comparisons
before any SRAM and afterward, two status snapshots separated by two seconds,
derived aligned/merged ranges at most16KiB per snapshot, strict bool/enum
decode errors, all raw brackets and command receipts. No peripheral registers
or full recorder body are read. Snapshot coherence remains UNPROVEN even if
all fields agree. First-failure packet offsets are not acknowledged bytes;
NOT_ATTEMPTED/ownership_evaluated=false never implies a cleanup attempt.
Observed status is not proof of delivery, cause, physical timing, motor safety
or a human phase gate.
