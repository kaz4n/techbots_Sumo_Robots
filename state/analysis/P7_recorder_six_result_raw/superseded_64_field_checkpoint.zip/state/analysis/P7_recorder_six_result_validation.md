# D238 source/host closure

SOURCE_HOST_ONLY_PASS. Seven focused Windows methods passed, zero failures,
errors or skips, in1.942s wall time. Receipt and exact stdout/stderr are under
P7_recorder_six_result_raw/tests01.*. No native command, MCU read, UART action,
upload, reset or cleanup was executed by this preparation.

The isolated worktree starts at MAIN8a74ec5abe4b8709261f1d5d3173eabf9e9c85d5.
All145 compiled input bytes match historical HEAD1b2af246cd88e6207e846ee340f8c4e46a5bb980
and the current isolated files. The unchanged source owner recomputes the exact
110 staged records and source289300a4be9547cd294dc1f753bbe17a429d16776c46467fec5417b1290f4ffc.
The four closed compile records were copied from the frozen native worktree's
recorder-771c04943d4c4a75 owner; each source was reread after copying to verify
byte equality. Their exact pins are in plan.json. The active run is separate.

Three exact reverse projections restore the accepted D233 ABI/capture/caller
templates. AST inspection rejects old attempt/head/session/source/package
identities in the new executable literals. No execution path, bound, guard or
data layout was changed. ABI tools still contain9 types,11 windows,64 fields,
9 enum types and533 GDB expression lines, including the same eight-byte first
record. Field/extent/overlap checks and invalid bool/enum refusals pass using
synthetic layouts. These are not actual target addresses or observations.

Real file-owner construction proves145 historical/current inputs,110 staged
files, four offline children, twelve file pins and the unchanged30000-unit
Windows command ceiling without invoking transport. Real capture adapter and
action composition prove the new fixed helper pin and complete263680B loader
plus55376B sketch plans before and after SRAM. Exact package hash is
3b4812a7a57ec964437d6d1048f96724e3fed5d0a3f9419acd26adbcd5e70a5d.
Existing descriptor/lifecycle/caller execution evidence remains accepted from
D230/D233; no redundant broad host suite or new framework is introduced.

New tool pins:

| File | Bytes | SHA-256 |
|---|---:|---|
| recorder_six_result_abi.py | 24790 | 229af33e939b0453f427a19a8ab043135dfe4646042cf372a1843199b12ec9a1 |
| recorder_six_result_capture.py | 11770 | 2dfd19f72aa913660f8b32b113093047976d03c218bb793a7aa973b0d2765d5d |
| run_recorder_six_result_capture.py | 19593 | b46893c3e6cf7ce258a3eeaf221074770d1d80b64a425ff7058321c9c99114c2 |

Root next reviews and commits the exact preparation, then may execute one
file-only check/ABI from this worktree while the receiver remains bounded.
Fresh accepted ABI data mechanically supplies the three absent-only capture
bindings; their preparation does not need another source-review chain. Actual
passive capture remains after delivery/receiver closure and may be omitted
when full validated delivery leaves no concrete concern. Coherence remains
UNPROVEN; a prepared workflow is not observed delivery, cause, timing, motor
permission or a passed human phase gate. No failed owner can be reused.

Storage: no compiler objects or generated full-image copies were created.
Keep the four small compile records, source projections, query plan, tests,
contracts and review as the reproducible source/host closure. Actual native
ABI/capture evidence remains absent until root independently executes it.
